The Python AI requires Python 2.7 to be installed on the client machine
(2.7.2 or higher recommended).  Only standard library modules have
been used, so no dependencies should need to be installed. Will NOT
work with Python 3000!